m = int(input("Nhập số hàng = "))
n = int(input("Nhập số cột = "))
a = []
for i in range(m):
    a.append([])
    for j in range(n):
        x = float(input("Nhập phần tử a[%d][%d] = " % (i+1, j+1)))
        a[i].append(x)
print("Ma trận vừa nhập là:")
for row in a:
    print(row)
with open("dulieu.txt", "w") as f:
    for row in a:
        f.write(" ".join(map(str, row)) + "\n")
print("Ma trận đã được ghi vào file dulieu.txt")