import math

def dien_tich_hinh_tron(r):
    return math.pi * r**2

def chu_vi_hinh_tron(r):
    return 2 * math.pi * r

def dien_tich_hcn(dai, rong):
    return dai * rong

def chu_vi_hcn(dai, rong):
    return 2 * (dai + rong)

def dien_tich_tam_giac(a, h):
    return 0.5 * a * h

def chu_vi_tam_giac(a, b, c):
    return a + b + c