#vidu
dan_toc = {
    1: "Kinh",
    2: "Tày",
    3: "Nùng",
    4: "Thái",
    5: "Khơ Me"
}
ma = int(input("Nhập mã dân tộc (1-5): "))
if ma in dan_toc:
    print("Dân tộc tương ứng là:", dan_toc[ma])
else:
    print("Mã dân tộc không hợp lệ!")