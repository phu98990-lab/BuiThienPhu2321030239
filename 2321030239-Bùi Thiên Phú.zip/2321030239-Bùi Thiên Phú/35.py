n = int(input("Nhap so phan tu n (0 < n < 100): "))
if n <= 0 or n >= 100:
    print("n khong hop le!")
else:
    arr = []
    for i in range(n):
        x = float(input(f"Nhap x[{i+1}]: "))
        arr.append(x)
    filtered = [x for x in arr if -1000 < x < -10]
    if filtered:
        avg = sum(filtered) / len(filtered)
        print("Trung binh cong cac phan tu am trong (-1000, -10):", round(avg, 2))
    else:
        print("Khong co phan tu nao thoa man!")