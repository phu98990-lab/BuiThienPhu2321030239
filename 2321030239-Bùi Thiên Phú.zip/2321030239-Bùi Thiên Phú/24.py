#vidu
m = int(input("Nhập số hàng: "))
n = int(input("Nhập số cột: "))
ma_tran = []
for i in range(m):
    hang = []
    for j in range(n):
        x = int(input(f"Nhập phần tử tại hàng {i+1}, cột {j+1}: "))
        hang.append(x)
    ma_tran.append(hang)
print("Ma trận vừa nhập là:")
for hang in ma_tran:
    print(hang)