#bai tap
a = float(input("Nhập số thực a: "))
b = float(input("Nhập số thực b: "))
c = float(input("Nhập số thực c: "))
min_val = min(a, b, c)
max_val = max(a, b, c)
print("Giá trị nhỏ nhất là:", min_val)
print("Giá trị lớn nhất là:", max_val)
