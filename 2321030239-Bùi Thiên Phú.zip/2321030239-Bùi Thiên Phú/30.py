x=int(input("nhap so thu nhat:"))
y=int(input("nhap so thu hai:"))
print("tong 2 so la:",cong(x,y))
print("hieu 2 so la:",hieu(x,y))
