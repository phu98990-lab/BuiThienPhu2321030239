#vidu
def sum(a, b=10):
    return a + b
print(sum(1, 2))  
print(sum(5)) 
#vidu
def sum(a, b, *p):
    s = a + b
    for i in p:
        s += i
    return s
print(sum(1, 2))          
print(sum(5, 10))         
print(sum(1, 2, 3, 4, 5)) 
#vidu
def msg():
    a = 10   
    print("Giá trị của a trong hàm là:", a)
    return
msg()
print(a)#