#vidu
x = int(input("Nhập số nguyên x: "))
y = int(input("Nhập số nguyên y: "))
if x == y:
    print("x = y")
elif x > y:
    print("x > y")
else:
    print("x < y")