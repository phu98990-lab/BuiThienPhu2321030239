#vi du
list1=['java','python','c++','php','sql']
list1.pop()
print("list:",list1)
list1.pop(2)
print("list:",list1)
# vi du
list1=['java','python','c++','php','sql']
list1.reverse()
print("list:",list1)
list1.remove('python')
print("list:",list1)
list1.clear()
print("list:",list1)
