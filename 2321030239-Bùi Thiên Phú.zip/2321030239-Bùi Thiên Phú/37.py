import math

class Circle:
    def nhap(self):
        self.bk = float(input("Nhập bán kính: "))
    
    def dientich(self):
        return math.pi * self.bk * self.bk

c = Circle()
c.nhap()
print("Diện tích hình tròn là:", c.dientich())