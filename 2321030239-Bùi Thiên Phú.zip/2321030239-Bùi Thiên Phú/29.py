#vidu
b=20
def msg():
    a=10
    print("gia tri cua a la:",a)
    print("gia trị cua b la:",b)
    return
msg()
print(b)    
