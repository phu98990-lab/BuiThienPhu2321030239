#vidu
n = int(input("Nhập số phần tử của dãy: "))
day_so = []
for i in range(n):
    x = int(input(f"Nhập phần tử thứ {i+1}: "))
    day_so.append(x)
print("Lũy thừa 2 của các phần tử trong dãy là:")
for x in day_so:
    print(x**2)