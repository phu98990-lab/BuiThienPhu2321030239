#vidu
var = 10
while var > 0:
    print("Giá trị hiện tại của biến là:", var)
    var -= 1   
    if var == 5:
        break
#vidu 
var = 5

while var > 0:
    var -= 1  
    if var == 3:
        continue   
    print("Giá trị biến hiện tại là:", var)        
        
        