n = int(input("Nhập số phần tử n: "))
while n <= 0 or n > 100:
    n = int(input("Nhập lại n (0 < n ≤ 100): "))

Tong = 0
dem = 0

for i in range(n):
    x = float(input(f"Nhập phần tử x[{i+1}]: "))
    if -100 < x < 10:
        Tong += x
        dem += 1

if dem > 0:
    TBC = Tong / dem
    print("Trung bình cộng các phần tử trong khoảng (-100, 10) là:", TBC)
else:
    print("Không có phần tử nào nằm trong khoảng (-100, 10).")