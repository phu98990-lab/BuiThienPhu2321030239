# ví dụ:
aTuple=('123','abc','xyz','def')
alist=list(aTuple)
print("cac phan tu trong tuple la:",aTuple)
print("cac phan tu trong list la:",alist)
# ví dụ 
list1=["java","python","c++"]
print("phan tu cua list truoc khi them la:",list1)
list1.append('php')
print("phan tu cua list sau khi them la:",list1)
