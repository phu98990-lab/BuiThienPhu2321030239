#ví dụ 1
print('lap trinh python')
a = 200
print('gia tri:',a)
print('xin chao cac ban sinh vien')
print('khoa cong nghe thong tin')
#ví dụ 2
print(230,250)
print(230,250,sep='*')
print(230,250,123,sep='-',end='!')