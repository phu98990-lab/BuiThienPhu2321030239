# bai tap
s = "234567"
list_int = [int(ch) for ch in s]
print("ma tran mot chieu la:", list_int)
# bai tap
A = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
    [2, 5, 8]
]
print(*zip(*A), sep="\n")