# ví dụ:
print('lap trinh {lang} {prop}'.format(lang='python', prop='co ban'))
# ví dụ:
a=100.50
print('gia tri la %2f' %a)