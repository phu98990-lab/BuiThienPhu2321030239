#vidu
tong = 0
for i in range(1, 7):
    tong += i
print("Tổng từ 1 đến 6 là:", tong)