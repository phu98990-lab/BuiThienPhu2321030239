#vidu
def is_perfect(n):
    tong_uoc = 0
    for i in range(1, n):
        if n % i == 0:
            tong_uoc += i
    return tong_uoc == n
perfect_numbers = []
for num in range(1, 100):
    if is_perfect(num):
        perfect_numbers.append(num)
print("Các số hoàn hảo nhỏ hơn 100 là:", perfect_numbers)