n = int(input("Nhap so phan tu n (0 < n < 200): "))
if n <= 0 or n >= 200:
    print("n khong hop le!")
else:
    arr = []
    for i in range(n):
        x = int(input(f"Nhap x[{i+1}]: "))
        arr.append(x)
    tong_chan = sum([x for x in arr if x % 2 == 0])
    print("Tong cac phan tu chan:", tong_chan)
    if tong_chan % 7 == 0 and tong_chan < 200:
        print("Tong chia het cho 7 va nho hon 200.")
    else:
        print("Tong khong thoa man dieu kien.")