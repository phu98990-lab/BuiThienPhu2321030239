#vidu
n = int(input("Nhập số tự nhiên n: "))
tong_uoc = 0
for i in range(1, n):
    if n % i == 0:
        tong_uoc += i
if tong_uoc == n:
    print(n, "là số hoàn hảo")
else:
    print(n, "không phải là số hoàn hảo")