class Circle:
    Pi = 3.1416
    def __init__(self, radius=1):
        self.radius = radius
    def perimeter(self):
        return self.radius * self.Pi * 2
c = Circle(5)
print("Perimeter là:", c.perimeter())