# vi du:
list1=['123','abc','xyz']
list2=['java','python','php','c++']
print("do dai cua list1 la:",len(list1))
print("do dai cua list2 là:",len(list2))
#vi du
list1=['123','xyz','def','abc']
list2=['222','333','111']
print("phan tu lon nhat list1 la:",max(list1))
print("phan tu lon nhat list2 la:",max(list2))