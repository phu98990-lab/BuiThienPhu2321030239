#vidu
toan = float(input("Nhập điểm Toán: "))
ly   = float(input("Nhập điểm Lý: "))
hoa  = float(input("Nhập điểm Hóa: "))
dtb = (toan + ly + hoa) / 3
if dtb < 5:
    print("Học lực: Yếu")
elif dtb < 7:
    print("Học lực: Trung bình")
elif dtb < 9:
    print("Học lực: Khá")
else:
    print("Học lực: Giỏi")