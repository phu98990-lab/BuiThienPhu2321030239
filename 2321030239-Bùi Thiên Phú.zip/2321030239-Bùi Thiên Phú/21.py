#vidu
n = int(input("Nhập số tự nhiên n: "))
def is_prime(x):
    if x < 2:
        return False
    for i in range(2, int(x**0.5) + 1):
        if x % i == 0:
            return False
    return True
uoc_nguyen_to = []
for i in range(1, n):
    if n % i == 0 and is_prime(i):
        uoc_nguyen_to.append(i)
if uoc_nguyen_to:
    print("Các ước số nguyên tố khác", n, "là:", uoc_nguyen_to)
else:
    print(n, "không có ước số nguyên tố khác chính nó")