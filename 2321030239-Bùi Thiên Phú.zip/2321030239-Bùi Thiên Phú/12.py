# vidu
n = int(input("Nhập một số nguyên: "))
if n % 2 == 0:
    print(n, "là số chẵn")
else:
    print(n, "là số lẻ")