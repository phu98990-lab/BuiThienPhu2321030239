#bai1
a = int(input("Nhap a: "))
b = int(input("Nhap b: "))
min_digit = min([int(d) for d in str(b)])
print("Chu so nho nhat cua b la:", min_digit)
if min_digit != 0 and a % min_digit == 0:
    print(f"{a} chia het cho {min_digit}")
else:
    print(f"{a} khong chia het cho {min_digit}")
#bai2
a = int(input("Nhap a: "))
b = int(input("Nhap b: "))
min_digit = min([int(d) for d in str(b)])
print("Chu so nho nhat cua b la:", min_digit)
if min_digit != 0 and a % min_digit == 0:
    print(f"{a} chia het cho {min_digit}")
else:
    print(f"{a} khong chia het cho {min_digit}")
    