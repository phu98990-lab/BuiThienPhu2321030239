#bai tap
s = "abcdefghijkl"   
print("Ký tự thứ 3:", s[2])       
print("Ký tự từ 4 đến 7:", s[3:7]) 
print("Ký tự thứ 11:", s[10])      
print("Toàn bộ xâu:", s)