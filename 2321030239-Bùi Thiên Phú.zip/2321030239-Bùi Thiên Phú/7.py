# ví dụ:
str='Hello World'
newstr=str.replace('Hello','Bye')
print(newstr)
# ví dụ
str='AA BB AA CC AA DD AA EE'
newstr=str.replace('AA','aa',2)
print(newstr)