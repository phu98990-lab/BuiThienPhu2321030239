import module1

print("Chọn bài toán:")
print("1. Diện tích hình tròn")
print("2. Chu vi hình tròn")
print("3. Diện tích hình chữ nhật")
print("4. Chu vi hình chữ nhật")
print("5. Diện tích tam giác")
print("6. Chu vi tam giác")

choice = int(input("Nhập lựa chọn: "))

if choice == 1:
    r = float(input("Nhập bán kính: "))
    print("Diện tích:", module1.dien_tich_hinh_tron(r))
elif choice == 2:
    r = float(input("Nhập bán kính: "))
    print("Chu vi:", module1.chu_vi_hinh_tron(r))
elif choice == 3:
    dai = float(input("Nhập chiều dài: "))
    rong = float(input("Nhập chiều rộng: "))
    print("Diện tích:", module1.dien_tich_hcn(dai, rong))
elif choice == 4:
    dai = float(input("Nhập chiều dài: "))
    rong = float(input("Nhập chiều rộng: "))
    print("Chu vi:", module1.chu_vi_hcn(dai, rong))
elif choice == 5:
    a = float(input("Nhập cạnh đáy: "))
    h = float(input("Nhập chiều cao: "))
    print("Diện tích:", module1.dien_tich_tam_giac(a, h))
elif choice == 6:
    a = float(input("Nhập cạnh a: "))
    b = float(input("Nhập cạnh b: "))
    c = float(input("Nhập cạnh c: "))
    print("Chu vi:", module1.chu_vi_tam_giac(a, b, c))
else:
    print("Lựa chọn không hợp lệ")