n = int(input("Nhập số phần tử của dãy số: "))
numbers = []

for i in range(1, n + 1):
    num = int(input(f"Nhập số thứ {i}: "))
    numbers.append(num)

# Ghi ra file dulieu.txt ở ổ E
obj = open("E:/dulieu.txt", "w")
for num in numbers:
    obj.write(str(num) + " ")
obj.close()

print("Dãy số đã được ghi vào file dulieu.txt")