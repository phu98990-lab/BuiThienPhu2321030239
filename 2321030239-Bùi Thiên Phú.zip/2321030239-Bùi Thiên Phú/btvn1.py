#btvn
day_so = list(map(int, input("Nhập dãy số (khác 0): ").split()))
tong_chan = 0
for x in day_so:
    if x != 0 and x % 2 == 0:
        tong_chan += x
print("Tổng các số chẵn trong dãy là:", tong_chan)