# ví dụ:
list1=['java','python','c++']
list2=['sql']
list1.extend(list2)
print("list sau khi mo rong la:",list1)
# ví dụ
list1=['java','python','c++','php','sql']
print("chi muc cua 'python' la:",list1.index('python'))
print("chi muc cua 'php' la:",list1.index('php'))
# ví dụ
list1=['java','python','c++','php','sql']
list1.insert(3,'android')
print("list sau khi duoc chen la:",list1)
