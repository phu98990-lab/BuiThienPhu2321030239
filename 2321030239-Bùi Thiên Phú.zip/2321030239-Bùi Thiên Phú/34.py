#vidu
import numpy as np
ma = np.loadtxt("matran.txt")
print("Tổng của ma trận là:", ma.sum())
#vidu
def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True
with open("input.txt", "r") as f:
    numbers = [int(line.strip()) for line in f]
with open("output.txt", "w") as f:
    for num in numbers:
        if is_prime(num):
            f.write(f"{num} là số nguyên tố\n")
        else:
            f.write(f"{num} không phải số nguyên tố\n")
#vidu
with open("abc.txt", "w") as f0:
    f0.write("Python là 1 ngôn ngữ lập trình tuyệt vời\n")
    f0.write("Python cung cấp thư viện mạnh mẽ\n")            