#vidu
s = "ConChoFConline"
for ch in s:
    print(ch)