#vidu
n = int(input("Nhập số phần tử của dãy: "))
day_so = []
for i in range(n):
    x = int(input(f"Nhập phần tử thứ {i+1}: "))
    day_so.append(x)
tong = 0
for x in day_so:
    tong += x
print("Tổng các số trong dãy là:", tong)